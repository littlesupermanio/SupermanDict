package com.hhb.supermandict.constant;

/**
 * Created by HoHoibin on 08/01/2018.
 * Email: imhhb1997@gmail.com
 */

public class Constants {
    // 每日一句地址
    public static final String DAILY_SENTENCE = "http://open.iciba.com/dsapi";
    public static final String SHANBAY_API = "https://api.shanbay.com/bdc/search/?word=";
}
